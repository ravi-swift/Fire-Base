//
//  ViewController.swift
//  Firebase Demo
//
//  Created by Rp on 06/07/19.
//  Copyright © 2019 Rp. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassWord: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func clickOnSave(_ sender: Any) {
        //loginWithFirebase()
        
       // creatNewUser()
        
        resetPassword()
    }
    
    @IBAction func clickOnForgetPassword(_ sender: Any) {
        
    }
    
    func loginWithFirebase() {
        Auth.auth().signIn(withEmail: txtEmail.text!, password: txtPassWord.text!) { (user, error) in
            
            if error != nil {
                
            } else {
                print("Success login")
            }
        }
    }
    
    func creatNewUser() {
        Auth.auth().createUser(withEmail: txtEmail.text!, password: txtPassWord.text!) { (user, error) in
            
            if error != nil {
                
            } else {
                print("Success Create")
            }
        }
    }
    
    func resetPassword() {
        Auth.auth().sendPasswordReset(withEmail: txtEmail.text!) { (error) in
            
            self.txtEmail.text = ""
            
            if let error = error {
                //show alert here
                print(error.localizedDescription)
            }
            else {
                //show alert here
                print("We send you an email with instructions on how to reset your password.")
            }

        }
    }
    
}

